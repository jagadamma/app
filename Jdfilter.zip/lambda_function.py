import pymongo
from pymongo import MongoClient
import json
from bson import ObjectId

def lambda_handler(event, context):
    # TODO implement

    # Connect to the MongoDB Atlas cluster
    client = MongoClient("mongodb+srv://mongouser:mongoisbest@cluster0.9nbsswg.mongodb.net/?retryWrites=true&w=majority")

    # Access the desired database and collection
    db = client['JDs']
    collection = db['Jd']
    
    http_method = event['httpMethod']
    # Fetching the params provided in Event Body
    query = event['queryStringParameters'] or {}
    # query = json.dumps(query_params)

    
    if "title" in query:
        # Modify the query to search for the value of the "title" field using $text operator
        query["$text"] = {"$search": query.get("title")}
        del query["title"]
    
    if "salary" in query:
        # Modify the query to search greater than or equal to the "salary" field
        query["$expr"] = {"$gte": ["$optional.min_salary", float(query.get("salary"))]}
        del query["salary"]
        
    if "skills" in query:
        skill_list = query["skills"].split(',')
        # Replace the "skills" field with a new query object
        query["optional.skills"] = {"$in": skill_list}
        del query["skills"]
        
    if "qualifications" in query:
        query["optional.qualifications"] = query.get("qualifications")
        del query["qualifications"]
        
    if "id" in query:
        query = {"_id" : ObjectId(query.get("id"))}

    print(query)
    
    if query:
        documents = collection.find(query)
    
    # If nothing is mentioned then return every document in collection    
    else:
        # Find all documents
        documents = collection.find()
        
        
    # Creating a List of documents fetched and making a response  
    document_list = []
    for document in documents:
        document_dict = {}
        for key in document:
            # Convert ObjectId instances to string representations
            if isinstance(document[key], ObjectId):
                document_dict[key] = str(document[key])
            else:
                document_dict[key] = document[key]
        document_list.append(document_dict)

    # Convert list of dictionaries to JSON string
    json_str = json.dumps(document_list)

    # Set Lambda function response
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json_str
    }

    return response